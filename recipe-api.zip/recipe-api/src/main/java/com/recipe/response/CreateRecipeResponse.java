package com.recipe.response;


import com.recipe.model.Recipe;
import lombok.Getter;
import lombok.Setter;

/**
 * GetRecipeResponse model class
 * Represent model class for API response errors
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Getter
@Setter
public class CreateRecipeResponse extends RecipeApiResponse {
    Recipe recipe;
}
