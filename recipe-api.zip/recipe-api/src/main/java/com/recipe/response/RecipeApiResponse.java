package com.recipe.response;

import lombok.Getter;
import lombok.Setter;


/**
 * RecipeApiResponse model class
 * Represent generic response
 * for all API responses
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Getter
@Setter
public class RecipeApiResponse extends ErrorResponse {
}



