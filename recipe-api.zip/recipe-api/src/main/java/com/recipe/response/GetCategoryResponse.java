package com.recipe.response;


import com.recipe.model.Category;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * GetCategoryResponse model class
 * Represent model class for API response
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Getter
@Setter
public class GetCategoryResponse extends RecipeApiResponse {

    Category category;
}
