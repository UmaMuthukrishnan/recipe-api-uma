package com.recipe.service;

import com.recipe.model.Category;
import com.recipe.model.Recipe;
import com.recipe.response.CreateRecipeResponse;
import com.recipe.response.GetCategoryResponse;
import com.recipe.response.GetRecipeResponse;
import com.recipe.serviceClient.MongoDbServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * ArtistService class
 * Calls the service clients and builds response for
 * all API endpoints
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Service
public class RecipeService {

    @Autowired
    MongoDbServiceClient mongoDbServiceClient;

    /**
     * Obtains all Recipes
     *
     * @return GetRecipeResponse
     */
    public GetRecipeResponse getAllRecipes() {

        GetRecipeResponse getRecipeResponse = new GetRecipeResponse();
        List<Recipe> recipes = mongoDbServiceClient.getRecipes();
        getRecipeResponse.setRecipes(recipes);
        return getRecipeResponse;

    }

    /**
     * Saves Recipes
     *
     * @return GetRecipeResponse
     */

    public CreateRecipeResponse addRecipe(Recipe recipe) {

        CreateRecipeResponse createRecipeResponse = new CreateRecipeResponse();
        Recipe createdRecipe = mongoDbServiceClient.saveRecipe(recipe);
        createRecipeResponse.setRecipe(createdRecipe);
        return createRecipeResponse;

    }


    /**
     * Get Category
     *
     * @return GetCategoryResponse
     */

    public GetCategoryResponse getCategory() {

        GetCategoryResponse getCategoryResponse = new GetCategoryResponse();
        Category category = mongoDbServiceClient.getCategories();
        getCategoryResponse.setCategory(category);

        return getCategoryResponse;

    }


    /**
     * Obtains all Recipes by category regex search
     *
     * @return GetRecipeResponse
     */
    public GetRecipeResponse getAllRecipesSearchByCategory(String category) {

        GetRecipeResponse getRecipeResponse = new GetRecipeResponse();
        List<Recipe> recipes = mongoDbServiceClient.getRecipesByCategoryRegex(category);
        getRecipeResponse.setRecipes(recipes);
        return getRecipeResponse;

    }

    /**
     * Obtains all Recipes by title regex search
     *
     * @return GetRecipeResponse
     */
    public GetRecipeResponse getAllRecipesSearchByTitle(String title) {

        GetRecipeResponse getRecipeResponse = new GetRecipeResponse();
        List<Recipe> recipes = mongoDbServiceClient.getRecipesByNameRegex(title);
        getRecipeResponse.setRecipes(recipes);
        return getRecipeResponse;

    }

    /**
     * Obtains all Recipes by category and title regex search
     *
     * @return GetRecipeResponse
     */
    public GetRecipeResponse getAllRecipesSearchByCategoryAndTitle(String category, String title) {
        GetRecipeResponse getRecipeResponse = new GetRecipeResponse();
        List<Recipe> recipes = mongoDbServiceClient.getRecipesByCategoryAndNameRegex(category, title);
        getRecipeResponse.setRecipes(recipes);
        return getRecipeResponse;

    }
}
