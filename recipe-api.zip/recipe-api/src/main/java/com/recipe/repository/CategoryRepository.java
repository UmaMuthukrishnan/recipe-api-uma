package com.recipe.repository;

import com.recipe.model.Category;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * CategoryRepository Interface
 * Contains Methods for performing certain
 * operations on Recipe mongodb object
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
public interface CategoryRepository extends MongoRepository<Category, String> {
}
