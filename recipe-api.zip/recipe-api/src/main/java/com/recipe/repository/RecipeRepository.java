package com.recipe.repository;


import com.recipe.model.Recipe;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * RecipeRepository Interface
 * Contains Methods for performing certain
 * operations on Recipe mongodb object
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
public interface RecipeRepository extends MongoRepository<Recipe, String> {


    public List<Recipe> findByCategoriesRegex(String categoryFilter);

    public List<Recipe> findByCategoriesRegexAndTitleRegex(String categoryFilter, String title);

}
