package com.recipe.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

/**
 * Ingredient model class for mongo db
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Data
@Getter
@Setter

public class Ingredient {
    String item;
    Amount amt;

}
