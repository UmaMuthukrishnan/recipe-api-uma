package com.recipe.model;

import java.util.Set;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


/**
 * Category model class for mongo db
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Data
@Getter
@Setter
@Document(collection = "categoryRepository")
public class Category {

    @Id
    String categoryId;
    Set<String> category;
}
