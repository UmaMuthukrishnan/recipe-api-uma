package com.recipe.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * Amount model class for mongo db
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Data
@Getter
@Setter
public class Amount {
    String quantity;
    String unit;
}
