package com.recipe.model;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Recipe model class for mongo db
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Data
@Getter
@Setter
@Document(collection = "recipeRepo")
public class Recipe {
    @Id
    String title;
    Integer yield;
    String directions;
    List<Ingredient> ingredients;
    List<String> categories;

}
