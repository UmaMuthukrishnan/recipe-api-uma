package com.recipe.config;

public class ApplicationConfig {

    public static final String JSON_OPERATION_ERROR_CODE = "RECIPE_API-001";
    public static final String JSON_OPERATION_ERROR_NAME = "CANNOT READ JSON";
    public static final String JSON_OPERATION_ERROR_DESC = "CANNOT READ JSON PROPERTY";
    public static final String FILE_NOTFOUND_ERROR_CODE = "RECIPE_API-002";
    public static final String FILE_NOTFOUND_ERROR_NAME = "XML FILES NOT FOUND";
    public static final String FILE_NOTFOUND_ERROR_DESC = "XML FILES NOT FOUND PROPERTY";
}
