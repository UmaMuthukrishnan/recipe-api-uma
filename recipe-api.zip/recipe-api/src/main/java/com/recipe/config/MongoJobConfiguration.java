package com.recipe.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.recipe.exception.GenericException;
import com.recipe.exception.JsonOperationException;
import com.recipe.model.*;
import com.recipe.model.Error;
import com.recipe.repository.CategoryRepository;
import com.recipe.repository.RecipeRepository;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;

import static com.recipe.config.ApplicationConfig.JSON_OPERATION_ERROR_CODE;
import static com.recipe.config.ApplicationConfig.JSON_OPERATION_ERROR_DESC;
import static com.recipe.config.ApplicationConfig.JSON_OPERATION_ERROR_NAME;

@Configuration
@EnableBatchProcessing
@Slf4j
public class MongoJobConfiguration extends DefaultBatchConfigurer {
    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    RecipeRepository recipeRepository;

    @Autowired
    CategoryRepository categoryRepository;

    @Value("${recipe-file-list}")
    private String filesFromProperties;

    public static int PRETTY_PRINT_INDENT_FACTOR = 4;
    static Category categoryToSave = new Category();
    static Set<String> hSet = new HashSet<>();

    @Bean
    public Step insertDataFromFile() {
        return stepBuilderFactory.get("Inserting_values_in_database")
                .tasklet((stepContribution, chunkContext) -> {
                    List<String> fileList = Arrays.asList(filesFromProperties.split("\\s*,\\s*"));
                    fileList.forEach(this::insertFileDataIntoMongo);
                    categoryToSave.setCategoryId("categoryId");
                    categoryRepository.save(categoryToSave);
                    return RepeatStatus.FINISHED;
                }).build();
    }

    @Bean
    public Job xmlToJsonToMongo() {
        return jobBuilderFactory.get("XML_Processor")
                .start(insertDataFromFile())
                .build();
    }

    private void insertFileDataIntoMongo(String fileName) {
        File file;
        try {
            file = ResourceUtils.getFile("classpath:" + StringUtils.trimAllWhitespace(fileName));
        } catch (FileNotFoundException e) {
            throw new GenericException(new Error(ApplicationConfig.FILE_NOTFOUND_ERROR_CODE, ApplicationConfig.FILE_NOTFOUND_ERROR_NAME
                    , ApplicationConfig.FILE_NOTFOUND_ERROR_DESC, HttpStatus.BAD_REQUEST));
        }
        String fileToJson = processXML2JSON(file.toPath());
        insertToMongo(fileToJson);
    }

    private String processXML2JSON(Path xmlDocPath) throws JSONException {
        String xmlString = null;
        try {
            xmlString = Files.lines(xmlDocPath).collect(Collectors.joining("\n"));
        } catch (IOException e) {
            e.printStackTrace();
        }

        JSONObject xmlJSONObj = XML.toJSONObject(xmlString);
        String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root;
        try {
            root = mapper.readTree(jsonPrettyPrintString);
        } catch (IOException e) {
            throw new JsonOperationException(new Error(JSON_OPERATION_ERROR_CODE, JSON_OPERATION_ERROR_NAME,
                    JSON_OPERATION_ERROR_DESC, HttpStatus.INTERNAL_SERVER_ERROR),
                    "Error Reading JSON");
        }
        Recipe recipeToSave = new Recipe();
        if (root != null) {
            JsonNode recipeml = root.path("recipeml");
            JsonNode recipe = recipeml.findPath("recipe");
            if(recipe!=null) {
                JsonNode direction = recipe.findPath("directions");
                if(direction!=null) {
                    recipeToSave.setDirections(direction.get("step").asText());
                }
                JsonNode head = recipe.findPath("head");
                if(head!=null) {
                    recipeToSave.setYield( head.get("yield").asInt());
                    recipeToSave.setTitle(head.get("title").asText());
                    getCategoryList(mapper, recipeToSave, head);
                }
                JsonNode ingredients = recipe.findPath("ingredients");
                if(ingredients!=null) {
                    List<Ingredient> ingredientList = getIngredientList(ingredients);
                    recipeToSave.setIngredients(ingredientList);
                }

                recipeRepository.save(recipeToSave);
            }

        }
        return jsonPrettyPrintString;
    }

    private void getCategoryList(ObjectMapper mapper, Recipe recipeToSave, JsonNode head) {
        JsonNode category = head.get("categories");
        JsonNode cat = category.get("cat");
        if (cat != null && cat.isArray()) {
            try {
                List<String> list = mapper.readValue(cat.toString(), TypeFactory.defaultInstance().constructCollectionType(List.class, String.class));
                hSet.addAll(list);
                categoryToSave.setCategory(hSet);
                recipeToSave.setCategories(list);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private List<Ingredient> getIngredientList(JsonNode ingredients) {
        JsonNode ingList = ingredients.findPath("ing");
        List<Ingredient> ingredientList = new ArrayList<>();
        if (ingList != null && ingList.isArray()) {
            ingList.forEach(ingNode -> getIngredient(ingredientList, ingNode));
        }
        return ingredientList;
    }

    private void getIngredient(List<Ingredient> ingredientList, JsonNode ingNode) {
        Ingredient ingredient = new Ingredient();
        JsonNode itemNode = ingNode.get("item");
        if (itemNode != null) {
            ingredient.setItem(ingNode.get("item").asText());
        }
        JsonNode amtNode = ingNode.get("amt");
        if (amtNode != null) {
            Amount amount = new Amount();
            String amtUnit = amtNode.get("unit").asText();
            String amtQty = amtNode.get("qty").asText();
            amount.setUnit(amtUnit);
            amount.setQuantity(amtQty);
            ingredient.setAmt(amount);
        }
        ingredientList.add(ingredient);
    }

    private void insertToMongo(String jsonString) {
        Document doc = Document.parse(jsonString);
        mongoTemplate.insert(doc, "recipe");
    }
}
