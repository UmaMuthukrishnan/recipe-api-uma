package com.recipe.controller;

import com.recipe.model.Recipe;
import com.recipe.response.CreateRecipeResponse;
import com.recipe.response.GetCategoryResponse;
import com.recipe.response.GetRecipeResponse;
import com.recipe.response.RecipeApiResponse;
import com.recipe.service.RecipeService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * The main Controller class for the API
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@RestController
@Slf4j
public class RecipeController {


    private final RecipeService recipeService;

    @Autowired
    public RecipeController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    /**
     * Get list of all recipes
     *
     * @return ResponseEntity
     */
    @GetMapping(value = "/recipes", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Get list of all recipes")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved List of recipe"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<?> getAllRecipes(@RequestParam(required = false) String filter, @RequestParam(required = false) String name,
                                           @RequestParam(required = false) String category) {
        log.info("Invoking getAllRecipes");
        GetRecipeResponse getRecipeResponse = recipeService.getAllRecipes();
        return apiResponse(getRecipeResponse);
    }

    /**
     * Get filtered list of all recipes
     *
     * @return ResponseEntity
     */
    @GetMapping(value = "/recipes/filter", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Get list of all recipes")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved List of recipe"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<?> getFilteredRecipes(@RequestParam(required = false) String name,
                                                @RequestParam(required = false) String category) {
        log.info("Invoking getFilteredRecipes");
        GetRecipeResponse getRecipeResponse;
        if (StringUtils.isNotBlank(category) && StringUtils.isNotBlank(name)) {
            getRecipeResponse = recipeService.getAllRecipesSearchByCategoryAndTitle(category, name);
        } else if (StringUtils.isNotBlank(category) && (name == null || StringUtils.isBlank(name))) {
            getRecipeResponse = recipeService.getAllRecipesSearchByCategory(category);
        } else if (StringUtils.isNotBlank(name) && (category == null || StringUtils.isBlank(category))) {
            getRecipeResponse = recipeService.getAllRecipesSearchByTitle(name);
        } else {
            getRecipeResponse = recipeService.getAllRecipes();
        }
        return apiResponse(getRecipeResponse);
    }

    /**
     * Create Recipe
     *
     * @param recipe Recipe object
     * @return ResponseEntity
     */

    @PostMapping(value = "/recipe")
    @ApiOperation(value = "Create Recipe")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully created "),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<?> addRecipe(@RequestBody Recipe recipe) {

        log.info("Invoking add recipe");

        CreateRecipeResponse recipeCreated = recipeService.addRecipe(recipe);
        log.info("Invoking add recipe done");
        return apiResponse(recipeCreated);
    }

    /**
     * Get list of all categories
     *
     * @return ResponseEntity
     */
    @GetMapping(value = "/categories", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Get list of all categories")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved List of categories"),
            @ApiResponse(code = 400, message = "Bad request"),
            @ApiResponse(code = 404, message = "Resource Not Found")
    })
    public ResponseEntity<?> getAllCategories() {

        log.debug("Invoking getAllCategories");
        GetCategoryResponse getCategoryResponse = recipeService.getCategory();
        return apiResponse(getCategoryResponse);
    }


    /**
     * Converts all responses to ResponseEntity
     *
     * @param response RecipeApiResponse object
     * @return ResponseEntity
     */
    private static ResponseEntity<?> apiResponse(RecipeApiResponse response) {

        HttpStatus status = HttpStatus.OK;
        if (response != null && response.getErrors() != null && !response.getErrors().isEmpty()) {
            response.getErrors().sort((e1, e2) -> {
                if (e1.getHttpStatus().value() == e2.getHttpStatus().value()) {
                    return 0;
                }
                return e1.getHttpStatus().value() > e2.getHttpStatus().value() ? -1 : 1;
            });

            status = response.getErrors().get(0).getHttpStatus();
        }

        return ResponseEntity.status(status).cacheControl(CacheControl.noStore().cachePrivate()).body(response);
    }


}
