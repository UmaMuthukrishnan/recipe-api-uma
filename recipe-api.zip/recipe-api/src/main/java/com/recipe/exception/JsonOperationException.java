package com.recipe.exception;

import lombok.Getter;
import com.recipe.model.Error;


/** JsonOperation Exception Handler for the API
 * @author Proma Chowdhury
 * @version 1.0
 */
@Getter
public class JsonOperationException  extends GenericException {

    String message;
    public JsonOperationException(Error error, String message) {
        super(error);
        this.message = message;

    }
}
