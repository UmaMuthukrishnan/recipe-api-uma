package com.recipe.serviceClient;

import com.recipe.exception.MongoDbException;
import com.recipe.model.Category;
import com.recipe.model.Recipe;
import com.recipe.repository.CategoryRepository;
import com.recipe.repository.RecipeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * MongoDbServiceClient
 * Contains all mongodb operations
 *
 * @author Proma Chowdhury
 * @version 1.0
 */
@Service
public class MongoDbServiceClient {

    @Autowired
    RecipeRepository recipeRepository;
    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    MongoTemplate mongoTemplate;

    /**
     * Obtains all Recipes from the db
     *
     * @return List<Recipe>
     */
    public List<Recipe> getRecipes() {
        List<Recipe> recipes;
        try {
            recipes = recipeRepository.findAll();
        } catch (Exception e) {
            throw new MongoDbException("Error retrieving Recipe Details from db", e);
        }
        return recipes;
    }

    /**
     * saves  Recipe to the db
     *
     * @return Recipe
     */
    public Recipe saveRecipe(Recipe recipe) {
        Recipe savedRecipe;
        try {
            savedRecipe = recipeRepository.save(recipe);
//            Query query = new Query();
//            query.addCriteria(Criteria.where("categoryId").is("categoryId"));
//            Update update = new Update();
//            update.addToSet("category").each(recipe.getCategories());
//
//            Category categoryModified = mongoTemplate.findAndModify(query, update, Category.class);


        } catch (Exception e) {
            throw new MongoDbException("Error saving recipe to db", e);
        }
        return savedRecipe;
    }


    /**
     * Obtains all categories from the db
     *
     * @return List<Category>
     */
    public Category getCategories() {
        Category category;
        try {
            category = categoryRepository.findAll().get(0);
        } catch (Exception e) {
            throw new MongoDbException("Error retrieving Category Details from db", e);
        }
        return category;
    }


    /**
     * Obtains all Recipes from the db based on category filter
     *
     * @return List<Recipe>
     */
    public List<Recipe> getRecipesByCategoryRegex(String categoryRegex) {
        List<Recipe> recipes;
        try {
            recipes = searchRecipeByCategory(categoryRegex);
        } catch (Exception e) {
            throw new MongoDbException("Error retrieving Recipe Details from db", e);
        }
        return recipes;
    }


    /**
     * Obtains all Recipes from the db based on category & title filter
     *
     * @return List<Recipe>
     */
    public List<Recipe> getRecipesByCategoryAndNameRegex(String categoryRegex, String titleRegex) {
        List<Recipe> recipes;
        try {
            recipes = searchRecipeByCategoryAndName(categoryRegex, titleRegex);
        } catch (Exception e) {
            throw new MongoDbException("Error retrieving Recipe Details from db", e);
        }
        return recipes;
    }

    public List<Recipe> getRecipesByNameRegex(String titleRegex) {
        List<Recipe> recipes;
        try {
            recipes = searchRecipeByName(titleRegex);
        } catch (Exception e) {
            throw new MongoDbException("Error retrieving Recipe Details from db", e);
        }
        return recipes;
    }

    public List<Recipe> searchRecipeByCategory(String category) {
        Query query = new Query();
        query.addCriteria(Criteria.where("categories").regex(category, "i"));
        return mongoTemplate.find(query, Recipe.class);
    }


    public List<Recipe> searchRecipeByCategoryAndName(String category, String title) {
        Query query = new Query();
        query.addCriteria(Criteria.where("categories").regex(category, "i"));
        query.addCriteria(Criteria.where("title").regex(title, "i"));
        return mongoTemplate.find(query, Recipe.class);
    }

    public List<Recipe> searchRecipeByName(String title) {
        Query query = new Query();
        query.addCriteria(Criteria.where("title").regex(title, "i"));
        return mongoTemplate.find(query, Recipe.class);
    }

}
